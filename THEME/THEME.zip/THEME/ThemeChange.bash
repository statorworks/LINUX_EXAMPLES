#!/bin/bash

menu_option_1() {
  echo "Changing to Orangegutan.."
  cp -r Zerobot_orange/* /home/pi/.themes/Zerobot
  #
  cp -r Icons/folder_orange.png /usr/share/icons/Zerobot/32x32/places/folder.png
  cp -r Icons/folder_orange.png /usr/share/icons/Zerobot/40x40/places/folder.png
  cp -r Icons/folder_orange.png /usr/share/icons/Zerobot/48x48/places/folder.png
  cp -r Icons/folder_orange.png /usr/share/icons/Zerobot/64x64/places/folder.png
  #
  cp -r Icons/panel_orange.png /usr/share/lxpanel/images/zerobot_panel_image.png
}

menu_option_2() {
  echo "Changing to PunkBerry.."
  cp -r Zerobot_red/* /home/pi/.themes/Zerobot
  #
  cp -r Icons/folder_red.png /usr/share/icons/Zerobot/32x32/places/folder.png
  cp -r Icons/folder_red.png /usr/share/icons/Zerobot/40x40/places/folder.png
  cp -r Icons/folder_red.png /usr/share/icons/Zerobot/48x48/places/folder.png
  cp -r Icons/folder_red.png /usr/share/icons/Zerobot/64x64/places/folder.png
  #
  cp -r Icons/panel_red.png /usr/share/lxpanel/images/zerobot_panel_image.png
}

menu_option_3() {
  echo "Changing to Greenix.."
  cp -r Zerobot_green/* /home/pi/.themes/Zerobot
  #
  cp -r Icons/folder_green.png /usr/share/icons/Zerobot/32x32/places/folder.png
  cp -r Icons/folder_green.png /usr/share/icons/Zerobot/40x40/places/folder.png
  cp -r Icons/folder_green.png /usr/share/icons/Zerobot/48x48/places/folder.png
  cp -r Icons/folder_green.png /usr/share/icons/Zerobot/64x64/places/folder.png
  #
  cp -r Icons/panel_green.png /usr/share/lxpanel/images/zerobot_panel_image.png
}

menu_option_4() {
  echo "Changing to Cyanaid.."
  cp -r Zerobot_cyan/* /home/pi/.themes/Zerobot
  #
  cp -r Icons/folder_cyan.png /usr/share/icons/Zerobot/32x32/places/folder.png
  cp -r Icons/folder_cyan.png /usr/share/icons/Zerobot/40x40/places/folder.png
  cp -r Icons/folder_cyan.png /usr/share/icons/Zerobot/48x48/places/folder.png
  cp -r Icons/folder_cyan.png /usr/share/icons/Zerobot/64x64/places/folder.png
  #
  cp -r Icons/panel_cyan.png /usr/share/lxpanel/images/zerobot_panel_image.png
}

menu_option_5() {
  echo "Changing to YellowMellow.."
  cp -r Zerobot_yellow/* /home/pi/.themes/Zerobot
  #
  cp -r Icons/folder_yellow.png /usr/share/icons/Zerobot/32x32/places/folder.png
  cp -r Icons/folder_yellow.png /usr/share/icons/Zerobot/40x40/places/folder.png
  cp -r Icons/folder_yellow.png /usr/share/icons/Zerobot/48x48/places/folder.png
  cp -r Icons/folder_yellow.png /usr/share/icons/Zerobot/64x64/places/folder.png
  #
  cp -r Icons/panel_yellow.png /usr/share/lxpanel/images/zerobot_panel_image.png
}

menu_option_6() {
  echo $(($RANDOM % 4))
}
  
show_done() {
  echo " "
  #echo -n "  Done, please reboot to see changes."
  #read
  read -t 5 -p "  Done, please reboot to see changes."
  clear
}


clear;
echo "Enter Zerobot theme color number:"
echo " "
echo "1 Orangegutan"
echo "2 PunkBerry"
echo "3 Greenix"
echo "4 Cyanaid"
echo "5 YellowMellow"
echo "6 Random"
echo " "
read selection
  
echo " "
case $selection in
    1 ) echo ""; menu_option_1 ; show_done ;;
    2 ) echo ""; menu_option_2 ; show_done ;;
    3 ) echo ""; menu_option_3 ; show_done ;;
    4 ) echo ""; menu_option_4 ; show_done ;;
    5 ) echo ""; menu_option_5 ; show_done ;;
    6 ) echo ""; menu_option_6 ; show_done ;;
    * ) read -t 1 -p "Invalid option";;
esac
