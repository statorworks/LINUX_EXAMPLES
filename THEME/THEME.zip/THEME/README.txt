Here you can change the dark neon color theme for Zerobot.

Double click on the ThemeChange.bash script and select your option.
This changes the window borders, basic folder icons and the task panel.

If you want a custom color you can copy and edit one of the existing themes
here and add it to the script.


The following folders must have proper permisssion to copy files over:
/home/pi/.themes 
/usr/share/icons 
/usr/share/lxpanel/images
(Already have permission on fresh Zerobot image)


Notes:
Themes based on 'PixFlat'
The <theme><name> entry on etc/xdg/openbox/lxde-pi-rc.xml is 'Zerobot'
The Themename and IconThemeName entries on etc/xdg/lxsession/desktop.conf are 'Zerobot'

The dark GTK theme is selected on /~/.config/gtk-3.0/settings.ini with:
[settings]
gtk-application-prefer-dark-theme=1


ToDo some day:
Fix the menu area on lxterminal, it doesn't match dark theme.
Customize more of the icons for a better match.
Automate entering the 'Zerobot' entry on configuration files. 
Automate generation of strings and images for an arbitray user color. 
